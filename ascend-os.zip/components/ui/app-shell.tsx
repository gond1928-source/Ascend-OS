"use client";

import { IconRail } from "./icon-rail";
import { NavPanel } from "./nav-panel";

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="shell">
      <IconRail />
      <NavPanel />
      <main className="shell-main">
        {children}
      </main>
    </div>
  );
}
