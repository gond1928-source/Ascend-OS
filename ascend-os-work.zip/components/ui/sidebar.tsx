"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  BarChart3,
  History,
  Trophy,
  Settings,
  Zap,
  Timer,
} from "lucide-react";
import { useSessions } from "@/hooks/useSessions";
import { useXP } from "@/hooks/useXP";

const NAV_ITEMS = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/analytics", label: "Analytics", icon: BarChart3 },
  { href: "/sessions", label: "Sessions", icon: History },
  { href: "/timer", label: "Timer", icon: Timer },
  { href: "/achievements", label: "Achievements", icon: Trophy },
  { href: "/settings", label: "Settings", icon: Settings },
];

export function Sidebar() {
  const pathname = usePathname();
  const { sessions } = useSessions();
  const xp = useXP(sessions);
  const pct = (xp.xpIntoLevel / (xp.xpIntoLevel + xp.xpToNextLevel)) * 100;

  return (
    <aside className="relative flex h-screen w-52 flex-shrink-0 flex-col border-r border-white/[0.06] bg-base-950/90 backdrop-blur-xl">
      {/* Top accent line */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-accent-violet/40 to-transparent" />

      {/* Logo */}
      <div className="flex items-center gap-2.5 px-4 py-5">
        <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-accent-violet/20 ring-1 ring-accent-violet/30">
          <Zap className="h-3.5 w-3.5 text-accent-violet" />
        </div>
        <span className="font-display text-[15px] font-semibold tracking-tight text-ink-50">ascend</span>
        <span className="ml-auto font-mono text-[10px] text-ink-500/60">os</span>
      </div>

      {/* Divider */}
      <div className="mx-4 mb-2 h-px bg-white/[0.05]" />

      {/* Nav */}
      <nav className="flex flex-1 flex-col gap-0.5 px-2 py-1">
        {NAV_ITEMS.map(({ href, label, icon: Icon }) => {
          const active = pathname?.startsWith(href);
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                "group relative flex items-center gap-2.5 rounded-lg px-3 py-2 text-[13px] font-medium transition-all duration-150",
                active
                  ? "bg-accent-violet/10 text-ink-100"
                  : "text-ink-500 hover:bg-white/[0.04] hover:text-ink-300"
              )}
            >
              {active && (
                <span className="absolute left-0 top-1/2 h-4 w-0.5 -translate-y-1/2 rounded-r-full bg-accent-violet" />
              )}
              <Icon
                className={cn(
                  "h-[15px] w-[15px] flex-shrink-0 transition-colors",
                  active ? "text-accent-violet" : "text-current"
                )}
              />
              {label}
            </Link>
          );
        })}
      </nav>

      {/* XP / level */}
      <div className="border-t border-white/[0.05] px-4 py-4">
        <div className="mb-1.5 flex items-center justify-between">
          <span className="font-mono text-[10px] uppercase tracking-wider text-ink-500">Level {xp.level}</span>
          <span className="font-mono text-[10px] text-ink-500">{xp.xp.toLocaleString()} XP</span>
        </div>
        <div className="h-[3px] w-full overflow-hidden rounded-full bg-base-800">
          <div
            className="h-full rounded-full bg-gradient-to-r from-accent-violet to-accent-sky transition-all duration-700"
            style={{ width: `${pct}%` }}
          />
        </div>
        <div className="mt-3 flex items-center gap-1.5">
          <span className="h-1.5 w-1.5 rounded-full bg-base-700" />
          <p className="font-mono text-[10px] text-ink-500/70">ActivityWatch: offline</p>
        </div>
      </div>
    </aside>
  );
}
