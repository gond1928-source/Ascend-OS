import { cn } from "@/lib/utils";
import { ReactNode } from "react";

interface CardProps {
  children: ReactNode;
  className?: string;
  title?: string;
  eyebrow?: string;
  action?: ReactNode;
}

export function Card({ children, className, title, eyebrow, action }: CardProps) {
  return (
    <div
      className={cn(
        "rounded-xl border border-white/[0.07] bg-base-900/70 p-5 backdrop-blur-sm",
        className
      )}
    >
      {(title || eyebrow || action) && (
        <div className="mb-4 flex items-start justify-between gap-3">
          <div>
            {eyebrow && (
              <p className="font-mono text-[10px] uppercase tracking-widest text-ink-500">
                {eyebrow}
              </p>
            )}
            {title && <h3 className="mt-0.5 font-display text-[15px] font-medium text-ink-50">{title}</h3>}
          </div>
          {action}
        </div>
      )}
      {children}
    </div>
  );
}
