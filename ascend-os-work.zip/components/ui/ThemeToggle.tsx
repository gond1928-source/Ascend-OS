"use client";

import { useTheme } from "@/lib/theme/ThemeProvider";

/**
 * ThemeToggle — drop into any sidebar, nav, or settings panel.
 * Cycles through all available themes.
 */
export function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();

  return (
    <button
      onClick={toggleTheme}
      aria-label={`Switch to ${theme === "dark" ? "glass" : "dark"} theme`}
      style={{
        display: "flex",
        alignItems: "center",
        gap: "var(--space-2)",
        padding: "var(--space-2) var(--space-3)",
        borderRadius: "var(--radius-md)",
        border: "1px solid var(--border-default)",
        background: "var(--surface-elevated)",
        color: "var(--text-secondary)",
        cursor: "pointer",
        fontSize: "13px",
        transition: "var(--transition-base)",
      }}
    >
      {theme === "dark" ? "🪟 Glass" : "🌑 Dark"}
    </button>
  );
}
