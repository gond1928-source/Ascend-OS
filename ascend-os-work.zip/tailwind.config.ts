import type { Config } from "tailwindcss";

/**
 * tailwind.config.ts
 *
 * All color/radius/shadow values point to CSS variables (tokens).
 * This means:
 *  - Tailwind classes like `bg-surface-panel` automatically theme-switch
 *  - No hardcoded hex values in Tailwind config or component classNames
 *  - New theme? Update tokens.css — Tailwind classes just follow
 */
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // Surfaces
        surface: {
          app:      "var(--surface-app)",
          sidebar:  "var(--surface-sidebar)",
          panel:    "var(--surface-panel)",
          elevated: "var(--surface-elevated)",
          overlay:  "var(--surface-overlay)",
        },
        // Text
        ink: {
          primary:   "var(--text-primary)",
          secondary: "var(--text-secondary)",
          muted:     "var(--text-muted)",
        },
        // Accents
        accent: {
          primary: "var(--accent-primary)",
          success: "var(--accent-success)",
          warning: "var(--accent-warning)",
          danger:  "var(--accent-danger)",
          info:    "var(--accent-info)",
        },
        // Borders (as background colors for dividers)
        border: {
          subtle:  "var(--border-subtle)",
          default: "var(--border-default)",
          strong:  "var(--border-strong)",
          accent:  "var(--border-accent)",
        },
      },
      borderRadius: {
        sm:   "var(--radius-sm)",
        md:   "var(--radius-md)",
        lg:   "var(--radius-lg)",
        xl:   "var(--radius-xl)",
        full: "var(--radius-full)",
      },
      boxShadow: {
        sm:   "var(--shadow-sm)",
        md:   "var(--shadow-md)",
        lg:   "var(--shadow-lg)",
        glow: "var(--shadow-glow)",
      },
      transitionDuration: {
        fast:  "100ms",
        base:  "180ms",
        slow:  "320ms",
      },
      fontFamily: {
        display: ["var(--font-display)"],
        body:    ["var(--font-body)"],
        mono:    ["var(--font-mono)"],
      },
    },
  },
  plugins: [],
};

export default config;
